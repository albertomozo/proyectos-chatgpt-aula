# Kit plantilla para proyectos en ChatGPT

1. Crea un proyecto propio de ChatGPT.
2. Copia el bloque de [INSTRUCCIONES-PARA-PEGAR.md](INSTRUCCIONES-PARA-PEGAR.md) en sus ajustes.
3. Añade únicamente los tres archivos de la carpeta fuentes: índice, contexto y expediente.
4. Ejecuta [el Prompt 00](prompts/00-configurar-contexto.md) en un chat nuevo del proyecto.
5. Revisa y guarda el resultado; actualiza las fuentes antes de abrir otro chat.
6. Continúa con [los siguientes prompts](prompts/README.md).

[Guía completa](docs/GUIA-INSTALACION-ALUMNADO.md) · [Guía Word](docs/guia-instalacion-alumnado.docx).

No subas el ZIP ni todos sus archivos a las fuentes. Las cuotas de carga de tu cuenta también se aplican a las actualizaciones. Conserva siempre una copia local de tu trabajo.
